#include "uart.h"


int main(){
  
	USART2_Init();
	
	//test_setup();
	printf("Hello there from main function");
	while(1){
	
	}

}